package com.entity;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


import com.entity.layer2.LoginDetail;
import com.entity.layer2.Registernetbank;

import com.entity.layer3.LoginDetailRepository;
import com.entity.layer3.RegisternetbankRepository;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootTest
class OnlineBankingApplicationTests {
	
	@Autowired
	LoginDetailRepository AK;
	@Autowired
	RegisternetbankRepository A;
	

	@Test
	void contextLoads() {
	
		List<LoginDetail> get=AK.getLoginDetails();
		for(LoginDetail as:get)
		{ 
			System.out.println(as.getTransactionPassword());
		
			System.out.println(as);
		}
	}
	
	@Test
	void testcase()
	{
		LoginDetail aa=new LoginDetail();
		//user.setApplicationDate(null);
		aa.setAccountno(1111);
		aa.setLoginPassword("www");
		aa.setTransactionPassword("akkska");
		
	

	}
	

}
