package com.entity.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer2.LoginDetail;

@Repository
public class LoginDetailRepositoryImpl implements LoginDetailRepository{
	
	private static final List<LoginDetail> LoginDetail = null;
	@PersistenceContext
	EntityManager entityManager;


	@Transactional
	public List<LoginDetail> getLoginDetails() {
		
		String s="from LoginDetail";
		Query query = entityManager.createQuery(s);
		List<LoginDetail> getLoginDetail=query.getResultList();
		return LoginDetail;
	}

	@Override
	public void get(LoginDetail logindetail) {
		// TODO Auto-generated method stub
		
	}

	
	@Override
	public LoginDetail get(int USER_ID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getAccountno() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getLoginPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTransactionPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getUserdetails1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public com.entity.layer2.LoginDetail get1(long accountno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.entity.layer2.LoginDetail get1(String LoginPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public com.entity.layer2.LoginDetail get(String TransactionPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
//	public Fund_Transfer1 get(int Transactionid) {
//		// TODO Auto-generated method stub
//		return null;
//	}

//	@Override
//	public List<Fund_Transfer1> getAll() {
//		// TODO Auto-generated method stub
//		return null;
	//}

}
