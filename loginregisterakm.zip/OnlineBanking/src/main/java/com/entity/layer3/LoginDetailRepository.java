package com.entity.layer3;

import java.util.List;


import com.entity.layer2.LoginDetail;
import com.entity.layer2.Registernetbank;



public interface LoginDetailRepository {
	long getAccountno();
	String getLoginPassword();
	String getTransactionPassword();
	 void getUserdetails1();
	 
	 
	 public void get(LoginDetail login );
		public LoginDetail get1(long accountno);
		public LoginDetail get1(String LoginPassword);
		
		public LoginDetail get(String TransactionPassword);
		List<LoginDetail> getLoginDetails();
		LoginDetail get(int USER_ID);
		
		
}
