package com.entity.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.entity.layer2.Registernetbank;

@Repository
public class RegisternetbankRepositoryImpl implements RegisternetbankRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
@Transactional	
public void adduser(Registernetbank registernetbank) {
	
	entityManager.persist(registernetbank);

}
}