
package com.entity.layer3;

import com.entity.layer2.Registernetbank;

public interface RegisternetbankRepository {

	public void adduser(Registernetbank registernetbank);
}